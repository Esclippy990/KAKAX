# Chat room

This is a chatroom made by Esclippy990.

# Remixing 🎤🎶

For remixing, the whole code in the server is .env'ed, so good luck figuring out that, RIP in the first place

And if you cannot figure out and try to connect to this server (chat-lol.glitch.me) instead with a static site, this server will kick you out 🦵💢

# Project membership / "Request to Join"

I do **NOT** accept membership requests. Neither will i invite anyone to edit. I feel more comfortable coding and updating this project alone.

# Admin (without editing permissions)

Ohh no i hope you did not ask for this...

Admin does not exist; There is no way to submit an admin application so i did not made admin anyway

# Anything else?

*YEET*

# What now?

Idrc get lost :)